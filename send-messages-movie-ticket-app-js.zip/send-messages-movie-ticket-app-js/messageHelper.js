/* Copyright (c) Meta Platforms, Inc. and affiliates.
 * All rights reserved.
 *
 * This source code is licensed under the license found in the
 * LICENSE file in the root directory of this source tree.
 */
const mysql = require("mysql");
var axios = require("axios");

function sendMessage(data) {
  var config = {
    method: "post",
    url: `https://graph.facebook.com/${process.env.API_VERSION}/${process.env.BUSINESS_PHONE_NUMBER_ID}/messages`,
    headers: {
      Authorization: `Bearer ${process.env.ACCESS_TOKEN}`,
      "Content-Type": "application/json",
    },
    data: data,
  };

  return axios(config);
}

function getTextMessageInput(recipient, text) {
  return JSON.stringify({
    messaging_product: "whatsapp",
    preview_url: false,
    recipient_type: "individual",
    to: recipient,
    type: "text",
    text: {
      body: text,
    },
  });
}

function getImgMessageInput(recipient, img) {
  return JSON.stringify({
    messaging_product: "whatsapp",
    preview_url: false,
    recipient_type: "individual",
    to: recipient,
    type: "image",
    image: {
      link: img,
    },
  });
}

function getVidMessageInput(recipient) {
  return JSON.stringify({
    messaging_product: "whatsapp",
    preview_url: false,
    recipient_type: "individual",
    to: recipient,
    type: "video",
    video: {
      caption: "Sample video",
      link: "https://github.com/Uniquebit/Uniquebit.github.io/blob/main/Pizza.mp4",
    },
  });
}

function getTemplatedMessageInput(recipient, movie, seats) {
  return JSON.stringify({
    messaging_product: "whatsapp",
    to: recipient,
    type: "template",
    template: {
      name: "pizza",
      language: {
        code: "en_US",
      },
      components: [
        {
          type: "header",
          parameters: [
            {
              type: "image",
              image: {
                link: movie.thumbnail,
              },
            },
          ],
        },
        {
          type: "body",
          parameters: [
            {
              type: "text",
              text: movie.title,
            },
            {
              type: "date_time",
              date_time: {
                fallback_value: movie.time,
              },
            },
            {
              type: "text",
              text: movie.venue,
            },
            {
              type: "text",
              text: seats,
            },
          ],
        },
      ],
    },
  });
}

const connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "root123",
  database: "uniquebit",
});


var cell = function() { 
  var mobile = [];
  console.log('1');
  const queryString = "SELECT Number FROM ub_contacts";
    connection.query(queryString, (err, rows, fields) => {
    const data = rows?.map((row) => {
      mobile.push(row.Number);
    });
    console.log(mobile, "5")    
  });
  return mobile;
}
module.exports = {
  cell: cell,
  sendMessage: sendMessage,
  getTextMessageInput: getTextMessageInput,
  getImgMessageInput: getImgMessageInput,
  getVidMessageInput: getVidMessageInput,
  getTemplatedMessageInput: getTemplatedMessageInput,
};
