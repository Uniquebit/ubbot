/* Copyright (c) Meta Platforms, Inc. and affiliates.
 * All rights reserved.
 *
 * This source code is licensed under the license found in the
 * LICENSE file in the root directory of this source tree.
 */
// const mysql = require("mysql");
var express = require("express");
var router = express.Router();
var bodyParser = require("body-parser");
require("dotenv").config();
var { movies } = require("../public/javascripts/movies");
const { cell, sendMessage, getTemplatedMessageInput } = require("../messageHelper");
const { raw } = require("body-parser");

router.use(bodyParser.json());
var number = cell();
console.log(number, 'Mobile Numbers')
router.post("/", function (req, res, next) {
  //var number = ["919022258389", "919326123182"]; 
  console.log(number, 'post &&&')
  var movie = movies.filter((v, i) => v.id == req.body.id)[0];

  //var data = getTemplatedMessageInput(process.env.RECIPIENT_NUMBER, movie, req.body.seats);
  console.log(number, '7')
  let data;
  // let newdata = [];
  number.forEach((element) => {
    // console.log("number", index );
    data = getTemplatedMessageInput(element, movie, req.body.seats);
  //   // newdata.push(data);
  //   //console.log(newdata)}

    // newdata.forEach((ele) => {
    sendMessage(data)
      .then(function (response) {
        // console.log("header", response)
        res.redirect("/catalog");
        // res.end();
        return;
      })
      .catch(function (error) {
        console.log("ERRRR_buy", error);
        return;
      });
    // });
  });
});

module.exports = router;
