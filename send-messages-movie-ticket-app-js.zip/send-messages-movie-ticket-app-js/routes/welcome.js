/* Copyright (c) Meta Platforms, Inc. and affiliates.
* All rights reserved.
*
* This source code is licensed under the license found in the
* LICENSE file in the root directory of this source tree.
*/

var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');
require('dotenv').config()
const { sendMessage, getTextMessageInput, getImgMessageInput, getVidMessageInput } = require("../messageHelper");

router.use(bodyParser.json());

router.post('/', function(req, res, next) {
    var data = getTextMessageInput(process.env.RECIPIENT_NUMBER, 'Welcome to the Movie Ticket Demo App for Node.js!');
    var imgdata = getImgMessageInput(process.env.RECIPIENT_NUMBER, 'https://thumbs.dreamstime.com/b/jpg-spelled-word-dice-letters-reflection-term-toy-cubes-bottom-studio-shot-white-background-46803015.jpg');
    var viddata = getVidMessageInput(process.env.RECIPIENT_NUMBER);
  
   console.log('Welcome', data)
  
   sendMessage(imgdata) 
   sendMessage(data)
   sendMessage(viddata)
    .then(function (response) {
      res.redirect('/catalog');
      return;
    })
    .catch(function (error) {
      console.log("ERRRR", error);
      return;
    });
});

module.exports = router;
