/* Copyright (c) Meta Platforms, Inc. and affiliates.
* All rights reserved.
*
* This source code is licensed under the license found in the
* LICENSE file in the root directory of this source tree.
*/

var movies = [{
  id: 1,
  title: '1441 Pizzeria, Juhu',
  thumbnail: 'https://raw.githubusercontent.com/Uniquebit/Uniquebit.github.io/main/WhatsApp%20Image%202023-02-15%20at%203.19.48%20PM.jpeg',
  license: 'https://pixabay.com/photos/war-soldiers-parachutes-469503/',
  licenseDetails: 'Pixabay License / Free for commercial use / No attribution required',
  time: 'February 15, 2022 - 8:00 PM',
  venue: 'Shop No. 1, Plot No. 9, Nirav Apartment'
},
{
  id: 2,
  title: 'Storm in the Pacific',
  thumbnail: 'https://raw.githubusercontent.com/Uniquebit/Uniquebit.github.io/main/Grow-More-Logo.png',
  license: 'https://pixabay.com/photos/ship-strom-sea-night-fantasy-red-2202910/',
  licenseDetails: 'Pixabay License / Free for commercial use / No attribution required',
  time: 'October 24, 2022 - 7:30 PM',
  venue: 'Famous Studios'
},
{
  id: 3,
  title: 'Jewellery Store',
  thumbnail: 'https://res.cloudinary.com/hamstech/images/w_715,h_778/f_auto,q_auto/v1628752068/Hamstech%20App/Rajasthani-Jewellery-2/Rajasthani-Jewellery-2.jpg',
  license: 'https://pixabay.com/vectors/illustration-videogame-graphics-1736462/',
  licenseDetails: 'Pixabay License / Free for commercial use / No attribution required',
  time: 'October 24, 2022 - 10:30 PM',
  venue: 'Sonu Mahalaxmi'
},
{
  id: 4,
  title: 'Captain Doctor Angel II',
  thumbnail: 'https://cdn.zeebiz.com/sites/default/files/2022/09/19/200918-insurance-image-pixabay.jpg',
  license: 'https://pixabay.com/photos/doctor-physician-angel-care-3410941/',
  licenseDetails: 'Pixabay License / Free for commercial use / No attribution required',
  time: 'October 25, 2022 - 9:30 PM',
  venue: 'Uptown Studio'
}];

if (exports ) {
  exports.movies = movies;
}
